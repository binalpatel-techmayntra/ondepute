<?php

namespace App\Http\Controllers;

use App\Models\CompanyModel;
use Illuminate\Http\Request;
use Session;
class CompanyController extends Controller
{
  

  public function add_company_info(Request $request)
    {
    	$id = auth()->user()->id;
        if ($request->isMethod('post')) {
                $data = array
                (
                	"user_id"=>auth()->user()->id,
                   "date_of_incorporation"=>$request->post("date_of_incorporation"),
                    "classofcompany"=>$request->post("classofcompany"),
                    "tagline"=>$request->post("tagline"),
                    "pan"=>$request->post("pan"),
                    "description"=>$request->post("description"),
                    "email"=>$request->post("email"),
                    
                        );
                $sel_data = CompanyModel::where("user_id",$id)->get();

	        	if(sizeof($sel_data)==0)
	        	{
	        		$i = CompanyModel::insert($data);
	        	}
                else{
                	$i = CompanyModel::where("user_id",$id)->update($data);
                }
                
                if($i)
                {                   
                       
                     return redirect()->back()->with('success', 'Successfully Save Your Information'); 

                }
                else{
                     return redirect()->back()->with('fail', 'Failed To Save Information');
                }
        }
        else{
        	
        	$data = CompanyModel::where("user_id",$id)->get();

        	if(sizeof($data)==0)
        	{
        		return view("company/add_company_info", ["data"=>""]);
        	}
        	else{
            	return view("company/add_company_info", ["data"=>$data]);
        	}
        }
    }
}