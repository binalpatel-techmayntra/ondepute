

@include('layouts.partials.navbar')
<div class="pageTitle">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-sm-6">
        <h1 class="page-heading">Register</h1>
      </div>
      <div class="col-md-6 col-sm-6">
        <div class="breadCrumb"><a href="#.">Home</a> / <span>Register</span></div>
      </div>
    </div>
  </div>
</div>
<!-- Page Title End -->

<div class="listpgWraper">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <div class="userccount">
          <div class="socialLogin">
            <form method="post" action="{{ route('register.perform') }}">
            <!-- <h5>Login Or Register with Social</h5>
            <a href="#." class="fb"><i class="fa fa-facebook" aria-hidden="true"></i></a> <a href="#." class="gp"><i class="fa fa-google-plus" aria-hidden="true"></i></a> <a href="#." class="tw"><i class="fa fa-twitter" aria-hidden="true"></i></a>  -->
                
                
            <h3>Add Company Information({{ auth()->user()->name }})</h3>

             @include('layouts.partials.messages')
             <input type="hidden" name="_token" value="{{ csrf_token() }}" />
            </div>
          <!-- <div class="alert alert-success" role="alert"><strong>Well done!</strong> Your account successfully created.</div>
          <div class="alert alert-warning" role="alert"><strong>Warning!</strong> Better check yourself, you're not looking too good.</div>
          <div class="alert alert-danger" role="alert"><strong>Oh snap!</strong> Change a few things up and try submitting again.</div> -->
         <!--  <div class="userbtns">
            <ul class="nav nav-tabs">
              <li class="active"><a data-toggle="tab" href="#candidate">Candidate</a></li>
              <li><a data-toggle="tab" href="#employer">Employer</a></li>
            </ul>
          </div> -->
          <div class="tab-content">

            <div id="candidate" class="formpanel tab-pane fade in active">
              <div class="formrow">
              	<label>Enter Date Of Incorporation</label>
                <input type="date" class="form-control" name="	date_of_incorporation" placeholder="Enter Date Of Incorporation" required="required" autofocus>
              </div>
              <div class="formrow">
                <input type="text" class="form-control" name="username" value="{{ old('username') }}" placeholder="Username" required="required" required>
              </div>
              <div class="formrow">
                <input type="email" class="form-control" name="email" value="{{ old('email') }}" placeholder="Email" required="required">
              </div>
              <div class="formrow">
                <input type="password" class="form-control" name="password" value="{{ old('password') }}" placeholder="Password" required="required">
              </div>
              <div class="formrow">
                <input type="password" name="password_confirmation" value="{{ old('password_confirmation') }}" placeholder="Confirm Password" required="required" class="form-control">
              </div>
              <div class="formrow">
                <input type="checkbox" value="agree text" name="agree" />
                There are many variations of passages of Lorem Ipsum available</div>
              <input type="submit" class="btn" value="Register">
            </div>
          <!--   <div id="employer" class="formpanel tab-pane fade in">
              <div class="formrow">
                <input type="text" name="cname" class="form-control" placeholder="Company Name">
              </div>
              <div class="formrow">
                <input type="text" name="cusername" class="form-control" placeholder="Username">
              </div>
              <div class="formrow">
                <input type="text" name="cemail" class="form-control" placeholder="Email">
              </div>
              <div class="formrow">
                <input type="text" name="cpass" class="form-control" placeholder="Password">
              </div>
              <div class="formrow">
                <input type="text" name="cpass" class="form-control" placeholder="Confirm Password">
              </div>
              <div class="formrow">
                <input type="checkbox" value="agree text c" name="cagree" />
                There are many variations of passages of Lorem Ipsum available</div>
              <input type="submit" class="btn" value="Register">
            </div> -->
          </div>
      </form>
          <div class="newuser"><i class="fa fa-user" aria-hidden="true"></i> Already a Member? <a href="/login">Login Here</a></div>
        </div>
      </div>
    </div>
  </div>
</div>

@include('layouts.partials.footer')
<style type="text/css">
	label{
		margin-bottom: 10px;
		font-weight: bold;
	}
</style>