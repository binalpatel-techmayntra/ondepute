<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <ul>
                <li><?php echo \Session::get('success'); ?></li>
            </ul>
        </div>
    <?php endif; ?>


    <?php if(\Session::has('fail')): ?>
        <div class="alert alert-danger">
            <ul>
                <li><?php echo \Session::get('fail'); ?></li>
            </ul>
        </div>
    <?php endif; ?>



<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="au theme template">
<meta name="author" content="Hau Nguyen">
<meta name="keywords" content="au theme template">

<title>Dashboard</title>
<link href="<?php echo e(URL::asset('../css/font-face.css')); ?>" rel="stylesheet" media="all">
<link href="<?php echo e(URL::asset('../vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
<link href="<?php echo e(URL::asset('../vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">
<link href="<?php echo e(URL::asset('../vendor/mdi-font/css/material-design-iconic-font.min.css')); ?>" rel="stylesheet" media="all">

<link href="<?php echo e(URL::asset('../vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">

<!-- <link href="<?php echo e(URL::asset('vendor/animsition/animsition.min.css')); ?>" rel="stylesheet" media="all"> -->
<link href="<?php echo e(URL::asset('../vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css')); ?>" rel="stylesheet" media="all">
<link href="<?php echo e(URL::asset('../vendor/wow/animate.css')); ?>" rel="stylesheet" media="all">
<link href="<?php echo e(URL::asset('../vendor/css-hamburgers/hamburgers.min.css')); ?>" rel="stylesheet" media="all">
<link href="<?php echo e(URL::asset('../vendor/slick/slick.css')); ?>" rel="stylesheet" media="all">
<link href="<?php echo e(URL::asset('../vendor/select2/select2.min.css')); ?>" rel="stylesheet" media="all">
<link href="<?php echo e(URL::asset('../vendor/perfect-scrollbar/perfect-scrollbar.css')); ?>" rel="stylesheet" media="all">

<link href="<?php echo e(URL::asset('../css/theme.css')); ?>" rel="stylesheet" media="all">


<meta name="robots" content="index, nofollow">
<script>(function(w,d){!function(e,t,r,a,s){e[r]=e[r]||{},e[r].executed=[],e.zaraz={deferred:[]};var n=t.getElementsByTagName("title")[0];e[r].c=t.cookie,n&&(e[r].t=t.getElementsByTagName("title")[0].text),e[r].w=e.screen.width,e[r].h=e.screen.height,e[r].j=e.innerHeight,e[r].e=e.innerWidth,e[r].l=e.location.href,e[r].r=t.referrer,e[r].k=e.screen.colorDepth,e[r].n=t.characterSet,e[r].o=(new Date).getTimezoneOffset(),//
e[s]=e[s]||[],e.zaraz._preTrack=[],e.zaraz.track=(t,r)=>e.zaraz._preTrack.push([t,r]),e[s].push({"zaraz.start":(new Date).getTime()});var i=t.getElementsByTagName(a)[0],o=t.createElement(a);o.defer=!0,o.src="/cdn-cgi/zaraz/s.js?"+new URLSearchParams(e[r]).toString(),i.parentNode.insertBefore(o,i)}(w,d,"zarazData","script","dataLayer");})(window,document);</script></head>
<body class="animsition">
<div class="page-wrapper">

<header class="header-mobile d-block d-lg-none">
<div class="header-mobile__bar">
<div class="container-fluid">
<div class="header-mobile-inner">
<a class="logo" href="index.html">
<img src="<?php echo e(url('images/logo.png')); ?>" alt="CoolAdmin" />
</a>
<button class="hamburger hamburger--slider" type="button">
<span class="hamburger-box">
<span class="hamburger-inner"></span>
</span>
</button>
</div>
</div>
</div>
<nav class="navbar-mobile">
<div class="container-fluid">
<ul class="navbar-mobile__list list-unstyled">
<li class="has-sub">
<a class="js-arrow" href="#">
<i class="fas fa-tachometer-alt"></i>Dashboard</a>
<ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
<li>
<a href="index.html">Dashboard 1</a>
</li>
<li>
<a href="index2.html">Dashboard 2</a>
</li>
<li>
<a href="index3.html">Dashboard 3</a>
</li>
<li>
<a href="index4.html">Dashboard 4</a>
</li>
</ul>
</li>
<li>
<a href="chart.html">
<i class="fas fa-chart-bar"></i>Charts</a>
</li>
<li>
<a href="table.html">
<i class="fas fa-table"></i>Tables</a>
</li>
<li>
<a href="form.html">
<i class="far fa-check-square"></i>Forms</a>
 </li>
<li>
<a href="#">
<i class="fas fa-calendar-alt"></i>Calendar</a>
</li>
<li>
<a href="map.html">
<i class="fas fa-map-marker-alt"></i>Maps</a>
</li>
<li class="has-sub">
<a class="js-arrow" href="#">
<i class="fas fa-copy"></i>Pages</a>
<ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
<li>
<a href="login.html">Login</a>
</li>
<li>
<a href="register.html">Register</a>
</li>
<li>
<a href="forget-pass.html">Forget Password</a>
</li>
</ul>
</li>
<li class="has-sub">
<a class="js-arrow" href="#">
<i class="fas fa-desktop"></i>UI Elements</a>
<ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
<li>
<a href="button.html">Button</a>
</li>
<li>
<a href="badge.html">Badges</a>
</li>
<li>
<a href="tab.html">Tabs</a>
</li>
<li>
<a href="card.html">Cards</a>
</li>
<li>
<a href="alert.html">Alerts</a>
</li>
<li>
<a href="progress-bar.html">Progress Bars</a>
</li>
<li>
<a href="modal.html">Modals</a>
</li>
<li>
<a href="switch.html">Switchs</a>
</li>
<li>
<a href="grid.html">Grids</a>
</li>
<li>
<a href="fontawesome.html">Fontawesome Icon</a>
</li>
<li>
<a href="typo.html">Typography</a>
</li>
</ul>
</li>
</ul>
</div>
</nav>
</header>







<div class="page-container">

<header class="header-desktop">
<div class="section__content section__content--p30">
<div class="container-fluid">
<div class="header-wrap">
<form class="form-header" action="" method="POST">
<input class="au-input au-input--xl" type="text" name="search" placeholder="Search for datas &amp; reports..." />
<button class="au-btn--submit" type="submit">
<i class="zmdi zmdi-search"></i>
</button>
</form>
<div class="header-button">
<div class="noti-wrap">
<div class="noti__item js-item-menu">
<i class="zmdi zmdi-comment-more"></i>
<span class="quantity">1</span>
<div class="mess-dropdown js-dropdown">
<div class="mess__title">
<p>You have 2 news message</p>
</div>
<div class="mess__item">
<div class="image img-cir img-40">
<img src="images/icon/6.png" alt="Michelle Moreno" />
</div>
<div class="content">
<h6>Michelle Moreno</h6>
<p>Have sent a photo</p>
<span class="time">3 min ago</span>
</div>
</div>
<div class="mess__item">
<div class="image img-cir img-40">
<img src="images/icon/4.png" alt="Diane Myers" />
</div>
<div class="content">
<h6>Diane Myers</h6>
<p>You are now connected on message</p>
<span class="time">Yesterday</span>
</div>
</div>
<div class="mess__footer">
<a href="#">View all messages</a>
</div>
</div>
</div>
<div class="noti__item js-item-menu">
<i class="zmdi zmdi-email"></i>
<span class="quantity">1</span>
<div class="email-dropdown js-dropdown">
<div class="email__title">
<p>You have 3 New Emails</p>
</div>
<div class="email__item">
<div class="image img-cir img-40">
<img src="images/icon/6.png" alt="Cynthia Harvey" />
</div>
 <div class="content">
<p>Meeting about new dashboard...</p>
<span>Cynthia Harvey, 3 min ago</span>
</div>
</div>
<div class="email__item">
<div class="image img-cir img-40">
<img src="images/icon/5.png" alt="Cynthia Harvey" />
</div>
<div class="content">
<p>Meeting about new dashboard...</p>
<span>Cynthia Harvey, Yesterday</span>
</div>
</div>
<div class="email__item">
<div class="image img-cir img-40">
<img src="images/icon/4.png" alt="Cynthia Harvey" />
</div>
<div class="content">
<p>Meeting about new dashboard...</p>
<span>Cynthia Harvey, April 12,,2018</span>
</div>
</div>
<div class="email__footer">
<a href="#">See all emails</a>
</div>
</div>
</div>
<div class="noti__item js-item-menu">
<i class="zmdi zmdi-notifications"></i>
<span class="quantity">3</span>
<div class="notifi-dropdown js-dropdown">
<div class="notifi__title">
<p>You have 3 Notifications</p>
</div>
<div class="notifi__item">
<div class="bg-c1 img-cir img-40">
<i class="zmdi zmdi-email-open"></i>
</div>
<div class="content">
<p>You got a email notification</p>
<span class="date">April 12, 2018 06:50</span>
</div>
</div>
<div class="notifi__item">
<div class="bg-c2 img-cir img-40">
<i class="zmdi zmdi-account-box"></i>
</div>
<div class="content">
<p>Your account has been blocked</p>
<span class="date">April 12, 2018 06:50</span>
</div>
</div>
<div class="notifi__item">
<div class="bg-c3 img-cir img-40">
<i class="zmdi zmdi-file-text"></i>
 </div>
<div class="content">
<p>You got a new file</p>
<span class="date">April 12, 2018 06:50</span>
</div>
</div>
<div class="notifi__footer">
<a href="#">All notifications</a>
</div>
</div>
</div>
</div>
<div class="account-wrap">
<div class="account-item clearfix js-item-menu">
<div class="image">
<img src="<?php echo e(url('images/1.png')); ?>" alt="John Doe" />
</div>
<div class="content">
<a class="js-acc-btn" href="#">john doe</a>
</div>
<div class="account-dropdown js-dropdown">
<div class="info clearfix">
<div class="image">
<a href="#">
<img src="<?php echo e(url('images/1.png')); ?>" alt="John Doe" />
</a>
</div>
<div class="content">
<h5 class="name">
<a href="#">john doe</a>
</h5>
<span class="email"><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="bdd7d2d5d3d9d2d8fdd8c5dcd0cdd1d893ded2d0">[email&#160;protected]</a></span>
</div>
</div>
<div class="account-dropdown__body">
<div class="account-dropdown__item">
<a href="#">
<i class="zmdi zmdi-account"></i>Account</a>
</div>
<div class="account-dropdown__item">
<a href="#">
<i class="zmdi zmdi-settings"></i>Setting</a>
</div>
<div class="account-dropdown__item">
<a href="#">
<i class="zmdi zmdi-money-box"></i>Billing</a>
</div>
</div>
<div class="account-dropdown__footer">
<a href="/admin-logout">
<i class="zmdi zmdi-power"></i>Logout</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</header><?php /**PATH /var/www/html/new_ondepute/resources/views/admin/header.blade.php ENDPATH**/ ?>