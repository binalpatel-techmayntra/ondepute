<p class="mt-5 mb-3 text-muted">copyright &copy; <?php echo e(date('Y')); ?></p>
<?php /**PATH /var/www/html/new_ondepute/resources/views/auth/partials/copy.blade.php ENDPATH**/ ?>