


        
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.sharjeelanjum.com/html/jobs-portal/demo/index3.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 27 Jan 2022 11:24:21 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Online Job Portal HTML</title>
<!-- Fav Icon -->
<link rel="shortcut icon" href="favicon.ico">

<!-- Slider -->
<link href="<?php echo url('front/js/revolution-slider/css/settings.css'); ?>" rel="stylesheet">

<!-- Owl carousel -->
<link href="<?php echo url('front/css/owl.carousel.css'); ?>" rel="stylesheet">

<!-- Bootstrap -->
<link href="<?php echo url('front/css/bootstrap.min.css'); ?>" rel="stylesheet">

<!-- Font Awesome -->
<link href="<?php echo url('front/css/font-awesome.css'); ?>" rel="stylesheet">

<!-- Custom Style -->
<link href="<?php echo url('front/css/main.css'); ?>" rel="stylesheet">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="js/html5shiv.min.js"></script>
  <script src="js/respond.min.js"></script>
<![endif]-->
</head>
<div class="header">
  <div class="container">
    <div class="row">
      <div class="col-md-2 col-sm-3 col-xs-12"> <a href="index.html" class="logo"><img src="<?php echo e(url('front/images/logo.png')); ?>" alt="" /></a>
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
        <div class="clearfix"></div>
      </div>
      <div class="col-md-10 col-sm-12 col-xs-12"> 
        <!-- Nav start -->
        <div class="navbar navbar-default" role="navigation">
          <div class="navbar-collapse collapse" id="nav-main">
            <ul class="nav navbar-nav">
              <li class="active"><a href="/">Home <!-- <span class="caret"></span> --></a> 
                <!-- dropdown start -->
                <!-- <ul class="dropdown-menu">
                  <li><a href="index.html">Home Static Image</a></li>
                  <li><a href="index2.html">Home With Map</a></li>
                  <li class="active"><a href="index3.html">Home With Slider</a></li>
                </ul> -->
                <!-- dropdown end --> 
              </li>
              <li><a href="about-us.html">About us</a></li>
              <li class="dropdown"><a href="#.">Pages <span class="caret"></span></a> 
                <!-- dropdown start -->
                <ul class="dropdown-menu">
                  <li><a href="about-us.html">About Us</a></li>
                  
                    <?php if(auth()->guard()->guest()): ?>

                      <li><a href="/login">Login</a></li>
                      <li><a href="/register">Register</a></li>
                    <?php endif; ?>
                  
                  <?php if(auth()->guard()->check()): ?>                  
                  <li><a href="/employee">Manage Employee</a></li>
                  <li><a href="/add-company-info">Manage Company Information</a></li><li><a href="/logout">Logout</a></li>
                  <?php endif; ?>
                </ul>
                <!-- dropdown end --> 
              </li>
              
              <!-- <li class="dropdown"><a href="blog.html">Blog <span class="caret"></span></a>                
                <ul class="dropdown-menu">
                  <li><a href="blog.html">Blog List</a></li>
                  <li><a href="blog-detail.html">Blog Detail</a></li>
                  <li><a href="blog-grid.html">Blog Grid</a></li>
                  <li><a href="blog-full-width.html">Blog Grid Full Width</a></li>
                </ul>              
              </li> -->

              <li><a href="contact-us.html">Contact</a></li>
              <li class="postjob"><a href="post-job.html">Post a job</a></li>
              <li class="jobseeker"><a href="candidate-listing.html">Job Seeker</a></li>
              <?php if(auth()->guard()->check()): ?>
                  <li><a href="/add-company-info" style="color: green"><span style="font-weight: bold"><?php echo e(auth()->user()->name); ?></span>, Logged In</a></li>
              <?php endif; ?>
            </ul>
            <!-- Nav collapes end --> 
          </div>
          <div class="clearfix"></div>
        </div>
        <!-- Nav end --> 
      </div>
    </div>
    <!-- row end --> 
  </div>
  <!-- Header container end --> 
</div><?php /**PATH /var/www/html/new_ondepute/resources/views/layouts/partials/navbar.blade.php ENDPATH**/ ?>