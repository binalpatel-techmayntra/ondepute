<?php

namespace App\Http\Controllers;

use App\Models\CompanyModel;
use Illuminate\Http\Request;
use Session;
class CompanyController extends Controller
{
  

  public function add_company_info(Request $request)
    {
    	$id = auth()->user()->id;
        if ($request->isMethod('post')) {
        
        // $request->validate([
        //     'image' => 'required|pan_image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        // ]);
    
        $pan_image = time().$id.'.'.$request->pan_image->extension();  
     
        $request->pan_image->move(public_path('company_images'), $pan_image);



        // $request->validate([
        //     'image' => 'required|logo_image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        // ]);
    
        $logo_image = rand(0,1000).time().$id.'.'.$request->logo_image->extension();  
     
        $request->logo_image->move(public_path('company_images'), $logo_image);


        



        $data = array
                (
                	"user_id"=>auth()->user()->id,
                   "date_of_incorporation"=>$request->post("date_of_incorporation"),
                    "classofcompany"=>$request->post("classofcompany"),
                    "tagline"=>$request->post("tagline"),
                    "pan"=>$request->post("pan"),
                    "logo"=>$logo_image,
                    "pan_image"=>$pan_image,
                    "description"=>$request->post("description"),
                    "email"=>$request->post("email"),
                    
                        );
                $sel_data = CompanyModel::where("user_id",$id)->get();

	        	if(sizeof($sel_data)==0)
	        	{
	        		$i = CompanyModel::insert($data);
	        	}
                else{
                    //$pan_image_db = $sel_data[0]["pan_image"];
                    $pan_image_db = public_path('company_images/' . $sel_data[0]["pan_image"]);
                    $logo_db = public_path('company_images/' . $sel_data[0]["logo"]);
                    @unlink($pan_image_db);
                    @unlink($logo_db);
                	$i = CompanyModel::where("user_id",$id)->update($data);
                }
                
                if($i)
                {                   
                       
                     return redirect()->back()->with('success', 'Successfully Save Your Information'); 

                }
                else{
                     return redirect()->back()->with('fail', 'Failed To Save Information');
                }
        }
        else{
        	
        	$data = CompanyModel::where("user_id",$id)->get();

        	if(sizeof($data)==0)
        	{
        		return view("company/add_company_info", ["data"=>""]);
        	}
        	else{
            	return view("company/add_company_info", ["data"=>$data]);
        	}
        }
    }
}