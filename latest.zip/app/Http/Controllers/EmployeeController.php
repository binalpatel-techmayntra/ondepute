<?php

namespace App\Http\Controllers;

use App\Models\EmployeeModel;
use Illuminate\Http\Request;
use Session;
class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $id = auth()->user()->id;
        $data = EmployeeModel::where("company_id",$id)->get();
        return view("company/employee",["data"=>$data]);
    }

    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function add_employee(Request $request)
    {  
        $id = auth()->user()->id;   
        if ($request->isMethod('post')) {

            $image = time().$id.'.'.$request->image->extension();
            $request->image->move(public_path('employee_images'), $image);

            $panimage = time().$id.'.'.$request->panimage->extension();
            $request->panimage->move(public_path('employee_images'), $panimage);


            $adharimage = time().$id.'.'.$request->adharimage->extension();  
            $request->adharimage->move(public_path('employee_images'), $adharimage);


            $resume = time().$id.'.'.$request->resume->extension();  
            $request->resume->move(public_path('employee_images'), $resume);



                 $data = array
                (
                    //"user_id"=>auth()->user()->id,  
                    "name"=>@$request->post("name"),
                    "image"=>@$image,
                    "mobile"=>@$request->post("mobile"),
                    "email"=>@$request->post("email"),
                    "ismobileverify"=>@$request->post("ismobileverify"),
                    "isemailverify"=>@$request->post("isemailverify"),
                    "company_id"=>auth()->user()->id,
                    "totalexp"=>@$request->post("totalexp"),
                    "gender"=>@$request->post("gender"),
                    "pan"=>@$request->post("pan"),
                    "panimage"=>@$panimage,
                    "adharcard"=>@$request->post("adharcard"),
                    "adharimage"=>@$adharimage,
                    "uan"=>@$request->post("uan"),
                    "dob"=>@$request->post("dob"),
                    "isavailable"=>@$request->post("isavailable"),
                    "summary"=>@$request->post("summary"),
                    "current_package"=>@$request->post("current_package"),
                    "expected_package"=>@$request->post("expected_package"),
                    "available_for_time"=>@$request->post("available_for_time"),
                    "onsite"=>@$request->post("onsite"),
                    "resume"=>@$resume,
                    
                        );
                
                $i = EmployeeModel::insert($data);
                if($i)
                {                   
                       
                     return redirect('employee')->with('success', 'Successfully Save Your Information'); 

                }
                else{
                     return redirect()->back()->with('fail', 'Failed To Save Information');
                }
        }
        else{
            return view("company/add_employee");
        }
    }
   

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\EmployeeModel  $EmployeeModel
     * @return \Illuminate\Http\Response
     */
    public function show(EmployeeModel $EmployeeModel)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\EmployeeModel  $EmployeeModel
     * @return \Illuminate\Http\Response
     */
    public function edit(EmployeeModel $EmployeeModel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\EmployeeModel  $EmployeeModel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, EmployeeModel $EmployeeModel)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\EmployeeModel  $EmployeeModel
     * @return \Illuminate\Http\Response
     */
    public function destroy(EmployeeModel $EmployeeModel)
    {
        //
    }
}
