<?php

namespace App\Http\Controllers;

use App\Models\AdminModel;
use Illuminate\Http\Request;
use Session;
class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->isMethod('post')) {
                $data = array
                        (
                            "username"=>$request->post("username"),
                            "password"=>$request->post("password")
                        );
                $get = AdminModel::where($data)->get();
                $count = sizeof($get);
                if($count==1)
                {
                    $request->session()->put('admin', $request->input('username'));
                    Session::put('login_user_admin', $request->input('username'));  
                       
                     return redirect('admin-dashboard')->with('success', 'Admin Logged In');   

                }
                else{
                     return redirect()->back()->with('fail', 'Fail To Login');
                }
        }
        else{
            return view("admin/login");
        }
    }

    public function dashboard()
    {

        $admin =  Session("admin");
        if($admin=='')
        {

            return redirect('admin')->with('fail', 'Session Expired...Please Login');
         
        }
        else{
                return view("admin/header").view("admin/sidebar").view("admin/dashboard").view("admin/footer");
            }
    }

    public function logout()
    {
        Session::flush();
        return redirect('admin')->with('success', 'Successfully Logged Off');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\AdminModel  $adminModel
     * @return \Illuminate\Http\Response
     */
    public function show(AdminModel $adminModel)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\AdminModel  $adminModel
     * @return \Illuminate\Http\Response
     */
    public function edit(AdminModel $adminModel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\AdminModel  $adminModel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AdminModel $adminModel)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\AdminModel  $adminModel
     * @return \Illuminate\Http\Response
     */
    public function destroy(AdminModel $adminModel)
    {
        //
    }
}
