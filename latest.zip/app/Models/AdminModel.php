<?php

namespace App\Models;
use Eloquent;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdminModel extends Eloquent
{
   protected $table = 'admin';

   public function login($data)
   {
   		var_dump($data);
   }
}
