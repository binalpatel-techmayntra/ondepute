<script data-cfasync="false" src="{{ URL::asset('../email-decode.min.js') }}"></script>

<script src="{{ URL::asset('../vendor/bootstrap-4.1/popper.min.js') }}"></script>
<script src="{{ URL::asset('../vendor/bootstrap-4.1/bootstrap.min.js') }}"></script>

<script src="{{ URL::asset('../vendor/slick/slick.min.js') }}">
    </script>
<script src="{{ URL::asset('../vendor/wow/wow.min.js') }}"></script>
<script src="{{ URL::asset('../vendor/animsition/animsition.min.js') }}"></script>
<script src="{{ URL::asset('../vendor/bootstrap-progressbar/bootstrap-progressbar.min.js') }}">
    </script>
<script src="{{ URL::asset('../vendor/counter-up/jquery.waypoints.min.js') }}"></script>
<script src="{{ URL::asset('../vendor/counter-up/jquery.counterup.min.js') }}">
    </script>
<script src="{{ URL::asset('../vendor/circle-progress/circle-progress.min.js') }}"></script>
<script src="{{ URL::asset('../vendor/perfect-scrollbar/perfect-scrollbar.js') }}"></script>
<script src="{{ URL::asset('../vendor/chartjs/Chart.bundle.min.js') }}"></script>
<script src="{{ URL::asset('../vendor/select2/select2.min.js') }}">
    </script>

<script src="{{ URL::asset('../js/main.js') }}"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"6cccc83d2a5385b7","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2021.12.0","si":100}' crossorigin="anonymous"></script>
</body>
</html>

