 
@include("layouts.partials.navbar")

<div class="pageTitle">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-sm-6">
        <h1 class="page-heading">Add New Employee</h1>
      </div>
      <div class="col-md-6 col-sm-6">
        <div class="breadCrumb"><a href="#.">Home</a> / <span>Add Employee</span></div>
      </div>
    </div>
  </div>
</div>
<!-- Page Title End -->

<div class="listpgWraper">
  <div class="container">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">
        <div class="userccount">
          <div class="formpanel"> 
            
            <!-- Personal Information -->
            <h4>Add Employee</h4><hr>
            @include('layouts.partials.messages')
            <div class="row">
             <form  method="post" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="{{ csrf_token() }}" />
             <div class="col-md-6">
                <div class="formrow">
                	<label>Name</label>
                  <input type="text" name="name" class="form-control" placeholder="Enter Name" required="">
                </div>
              </div>

              <div class="col-md-6">
              	<label>Image</label>
                <div class="formrow">
                  <input type="file" accept="image/*" name="image" class="form-control">
                </div>
              </div> 
         

              <div class="col-md-6">
                <div class="formrow">
                  <label>Mobile</label>
                  <input type="text" name="mobile" class="form-control" placeholder="Mobile" required="">
                </div>
              </div>

              <div class="col-md-6">
                <div class="formrow">
                  <label>Email</label>
                  <input type="email" name="email" class="form-control" placeholder="Email" required="">
                </div>
              </div>

             
                
              

              


                <div class="col-md-6">
                <div class="formrow">                  
	            <label>Is Mobile Verified? </label><br>
             
	            <label class="radio-inline">
			      <input type="radio" name="ismobileverify" value="1" checked>Yes
			    </label>
			    <label class="radio-inline">
			      <input type="radio" name="ismobileverify" value="0">No
			    </label>			    
    
                </div>
                </div>

                <div class="col-md-6">
                <div class="formrow">                  
	            <label>Is Email Verified? </label><br>
             
	            <label class="radio-inline">
			      <input type="radio" name="isemailverify" value="1" checked>Yes
			    </label>
			    <label class="radio-inline">
			      <input type="radio" name="isemailverify" value="0">No
			    </label>			    
    
                </div>
                </div>
              

              
              
                
            </div>

             <hr>
            <div class="row">
              

                
            
              <!-- <div class="col-md-6">
                <div class="formrow">
                	<label>Company Id</label>
                  <input type="text"  name="company_id" class="form-control" placeholder="Company Id">
                </div>
              </div> -->

              <div class="col-md-6">
                <div class="formrow">                  
	            <label>Gender </label><br>
             
	            <br><label class="radio-inline">
			      <input type="radio" name="gender" value="male" checked>Male
			    </label>
			    <label class="radio-inline">
			      <input type="radio" name="gender" value="female">Female
			    </label>			    
    
                </div>
                </div>

              <div class="col-md-6">
                <div class="formrow">
                	<label>Total Experience</label>
                  <input type="text"  name="totalexp" class="form-control" placeholder="Total Experience">
                </div>
              </div>


              
            </div>
            <hr>

              

              
            	<div class="row">
                <div class="col-md-6">
                <div class="formrow">
                  <label>Pan Number</label>
                  <input type="text" name="pan" class="form-control" placeholder="Pan Number">
                </div>
              </div>

              <div class="col-md-6">
              	<label>Upload Pan Image</label>
                <div class="formrow">
                  <input type="file" name="panimage" accept="image/*" class="form-control">
                </div>
              </div>              

              <div class="col-md-6">
                <div class="formrow">
                  <label>Adhar Card Number</label>
                  <input type="text" name="adharcard" class="form-control" placeholder="Adhar Card Number">
                </div>
              </div>
                

              <div class="col-md-6">
              	<label>Upload Adhar Card Image</label>
                <div class="formrow">
                  <input type="file" name="adharimage" class="form-control" accept="image/*">
                </div>
              </div> 


              <div class="col-md-6">
                <div class="formrow">
                  <label>UAN Number</label>
                  <input type="text" name="uan" class="form-control" placeholder="UAN Number">
                </div>
              </div> 

              <div class="col-md-6">
                <div class="formrow">
                	<label>Date Of Birth</label>
                  <input type="date" name="dob" class="form-control" style="padding: 2px">
                </div>
              </div> 


            <hr>

            <div class="col-md-12" style="padding-right: 0">
                <div class="formrow">                  
	            <h5>IsAvailable?: </h5>
             
	            <label class="radio-inline">
			      <input type="radio" name="isavailable" value="yes" checked>yes
			    </label>
			    <label class="radio-inline">
			      <input type="radio" name="isavailable" value="no">no
			    </label>
			    <label class="radio-inline">
			      <input type="radio" name="isavailable" value="left">left
			    </label>
			    <label class="radio-inline">
			      <input type="radio" name="isavailable" value="notice_period">On Notice Period
			    </label>
    
                </div>
                </div>
            
          
            <!-- Education -->
            
            <div class="row">
              
              <div class="col-md-12">
                <div class="formrow">
                	<hr><h5>Summary</h5>
                  <textarea class="form-control" name="summary" placeholder="Summary"></textarea>
                </div>
              </div>
            </div>



            <div class="row">
              
              


              <div class="col-md-6">
                <div class="formrow">
                	<label>Current Package</label>
                  <input type="number" name="current_package" class="form-control" placeholder="Current Package">
                </div>
              </div>

              <div class="col-md-6">
                <div class="formrow">
                	<label>Expected Package</label>
                  <input type="number" name="expected_package" class="form-control" placeholder="Expected Package">
                </div>
              </div>



                <div class="col-md-6">
                <div class="formrow">  
                  <label>Available For Time</label>                
	              <input type="text" name="available_for_time" placeholder="Available For Time" class="form-control">
                </div>
                </div>  



                <div class="col-md-6">
                <div class="formrow">                  
	            <label>Onsite: </label><br><br>
             
	            <label class="radio-inline">
			      <input type="radio" name="onsite" value="1" checked>onsite
			    </label>
			    <label class="radio-inline">
			      <input type="radio" name="onsite" value="2">Remote
			    </label>
    
                </div>
                </div>  

                <div class="col-md-12">
                <div class="formrow">


                	<label>Upload Resume/CV</label>
                  <input type="file" name="resume" class="form-control">
                </div>
              </div>

            </div>



            
            <hr>
            
            
            <br>
            <input type="submit" class="btn" value="Save">
        	</form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<style type="text/css">
	label{
		margin-bottom:10px;
		font-weight: 500;
	}
	input[type='radio']{
		margin-top:2px;
	}
	
</style>