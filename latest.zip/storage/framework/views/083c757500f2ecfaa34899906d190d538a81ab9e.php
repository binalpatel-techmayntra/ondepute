

<?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="pageTitle">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-sm-6">
        <h1 class="page-heading">Register</h1>
      </div>
      <div class="col-md-6 col-sm-6">
        <div class="breadCrumb"><a href="#.">Home</a> / <span>Register</span></div>
      </div>
    </div>
  </div>
</div>
<!-- Page Title End -->

<div class="listpgWraper">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <div class="userccount">
          <div class="socialLogin">
            <form method="post" action="<?php echo e(route('register.perform')); ?>">
            <!-- <h5>Login Or Register with Social</h5>
            <a href="#." class="fb"><i class="fa fa-facebook" aria-hidden="true"></i></a> <a href="#." class="gp"><i class="fa fa-google-plus" aria-hidden="true"></i></a> <a href="#." class="tw"><i class="fa fa-twitter" aria-hidden="true"></i></a>  -->
                
                
            <h3>Register</h3>
             <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
            </div>
          <!-- <div class="alert alert-success" role="alert"><strong>Well done!</strong> Your account successfully created.</div>
          <div class="alert alert-warning" role="alert"><strong>Warning!</strong> Better check yourself, you're not looking too good.</div>
          <div class="alert alert-danger" role="alert"><strong>Oh snap!</strong> Change a few things up and try submitting again.</div> -->
         <!--  <div class="userbtns">
            <ul class="nav nav-tabs">
              <li class="active"><a data-toggle="tab" href="#candidate">Candidate</a></li>
              <li><a data-toggle="tab" href="#employer">Employer</a></li>
            </ul>
          </div> -->
          <div class="tab-content">

            <div id="candidate" class="formpanel tab-pane fade in active">
              <div class="formrow">
                <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" placeholder="name" required="required" autofocus>
              </div>

              <div class="formrow">
                <input type="text" class="form-control" name="cin" value="<?php echo e(old('cin')); ?>" placeholder="CIN" required="required" autofocus>
              </div>

              <div class="formrow">
                <input type="text" class="form-control" name="mobile" value="<?php echo e(old('mobile')); ?>" placeholder="Mobile" required="required" autofocus>
              </div>


              <div class="formrow">
                <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" placeholder="Username" required="required" required>
              </div>
              <div class="formrow">
                <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required="required">
              </div>
              <div class="formrow">
                <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="Password" required="required">
              </div>
              <div class="formrow">
                <input type="password" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" placeholder="Confirm Password" required="required" class="form-control">
              </div>
              <div class="formrow">
                <input type="checkbox" value="agree text" name="agree" />
                There are many variations of passages of Lorem Ipsum available</div>
              <input type="submit" class="btn" value="Register">
            </div>
          <!--   <div id="employer" class="formpanel tab-pane fade in">
              <div class="formrow">
                <input type="text" name="cname" class="form-control" placeholder="Company Name">
              </div>
              <div class="formrow">
                <input type="text" name="cusername" class="form-control" placeholder="Username">
              </div>
              <div class="formrow">
                <input type="text" name="cemail" class="form-control" placeholder="Email">
              </div>
              <div class="formrow">
                <input type="text" name="cpass" class="form-control" placeholder="Password">
              </div>
              <div class="formrow">
                <input type="text" name="cpass" class="form-control" placeholder="Confirm Password">
              </div>
              <div class="formrow">
                <input type="checkbox" value="agree text c" name="cagree" />
                There are many variations of passages of Lorem Ipsum available</div>
              <input type="submit" class="btn" value="Register">
            </div> -->
          </div>
      </form>
          <div class="newuser"><i class="fa fa-user" aria-hidden="true"></i> Already a Member? <a href="/login">Login Here</a></div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/new_ondepute/resources/views/auth/register.blade.php ENDPATH**/ ?>