<?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="pageTitle">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-sm-6">
        <h1 class="page-heading">Employee Listing</h1>
      </div>
      <div class="col-md-6 col-sm-6">
        <div class="breadCrumb"><a href="#.">Home</a> / <a href="#.">Resume Search</a> / <span>Employee</span></div>
      </div>
    </div>
  </div>
</div>
<!-- Page Title End -->

<div class="listpgWraper">
  <div class="row">
<a href="/add-employee" class="btn btn-primary" style="margin-top:-40px;float: right;margin-bottom: 20px;margin-right: 30px">Add New Employee</a>
</div>
  <div class="container"> 
    
    <!-- Search Result and sidebar start -->
    <div class="row">
       <h2>List Of Employees</h2>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Image</th>
        <th>name</th>
        <th>Mobile</th>
        <th>Email</th>
        <th>Total Exp</th>
        <th>Action</th>
      </tr>
    </thead>


    <tfoot>
      <tr>
        <th>Image</th>
        <th>name</th>
        <th>Mobile</th>
        <th>Email</th>
        <th>Total Exp</th>
        <th>Action</th>
      </tr>
    </tfoot>
    <tbody>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><img src="<?php echo e(url('employee_images/')); ?>/<?php echo e($r->image); ?>" alt="<?php echo e($r->name); ?>" /></td>
            <td><?php echo e($r->name); ?></td>
            <td><?php echo e($r->mobile); ?></td>
            <td><?php echo e($r->email); ?></td>
            <td><?php echo e($r->totalexp); ?></td>
            <td>
              <a href="#" class="btn btn-success">View Detail</a>
              <a href="#" class="btn btn-info">Add Skill</a>
              <a href="#" class="btn btn-primary">Add Education</a>
              <a href="#" class="btn btn-danger">Delete</a>              
            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </tbody>
  </table>

    </div>
  </div>
</div>

<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
  img{
    width: 80px;
  }
  th{
    font-weight: bold;
  }
</style><?php /**PATH /var/www/html/new_ondepute/resources/views/company/employee.blade.php ENDPATH**/ ?>