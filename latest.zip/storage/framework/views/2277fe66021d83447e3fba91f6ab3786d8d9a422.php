<?php echo $__env->make("layouts.partials.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="pageTitle">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-sm-6">
        <h1 class="page-heading">Add Company Information</h1>
      </div>
      <div class="col-md-6 col-sm-6">
        <div class="breadCrumb"><a href="#.">Home</a> / <span>Add Information</span></div>
      </div>
    </div>
  </div>
</div>
<!-- Page Title End -->

<div class="listpgWraper">
  <div class="container">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">
        <div class="userccount">
          <div class="formpanel"> 
            
            <!-- Personal Information -->
            <h4>Company Information (<?php echo e(auth()->user()->name); ?>)</h4><hr>
            <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
             <form  method="post" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
              <div class="col-md-6">
                <div class="formrow">
                  <label>Date Of Incorporation</label>
                  <input type="date" style="padding:1px" name="date_of_incorporation" value="<?php echo @$data[0]->date_of_incorporation ?>" class="form-control" required="">
                </div>
              </div>
              <!-- <div class="col-md-6">
                <div class="formrow">
                	<label>CIN</label>
                  <input type="text" name="cin" class="form-control" placeholder="Enter CIN">
                </div>
              </div> -->


              <div class="col-md-6">
                <div class="formrow">
                	<label>Class Of Company</label>
                  <select class="form-control" name="classofcompany" style="padding: 9px" required>
                  	<option value=" ">Select Class Of Company</option>
                  	<!-- <?php 
                  	if(@$data[0]->classofcompany!='')
                  	{
                  	?>
                  	<option><?php echo @$data[0]->classofcompany ?></option>
                  <?php } ?> -->
                    <option>Limited</option>
                    <option>Private Limited</option>
                    <option>LPP</option>
                    <option>Parternishp firm</option>
                    <option>INC</option>
                    <option>on person</option>
                  </select>
                </div>
              </div>
              <div class="col-md-6">
                <div class="formrow">
                	<label>tagline</label>
                  <input type="text" value="<?php echo @$data[0]->tagline ?>" name="tagline" class="form-control" placeholder="Tagline">
                </div>
              </div>

              <div class="col-md-6">
                <div class="formrow">
                  <label>Email</label>
                  <input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo @$data[0]->email ?>">
                </div>
              </div>

              <!-- <div class="col-md-6">
                <div class="formrow">
                  <label>Mobile</label>
                  <input type="text" name="mobile" class="form-control" placeholder="Mobile">
                </div>
              </div>
 -->
                <div class="col-md-6">
                <div class="formrow">
                  <label>Pan Number</label>
                  <input type="text" name="pan" class="form-control" placeholder="Pan Number" value="<?php echo @$data[0]->pan ?>">
                </div>
              </div>

              <div class="col-md-6">
              	<label>Pan Image</label>
                <div class="formrow">
                  <input type="file" name="pan_image" class="form-control" accept="image/*">
                </div>
              </div>   

              <div class="col-md-12">
              	<label>Upload Logo</label>
                <div class="formrow">
                  <input type="file" name="logo_image" class="form-control" accept="image/*">
                </div>
              </div>   

                     
            </div>
            <hr>
            
          
            <!-- Education -->
            <h5>Description</h5>
            <div class="row">
              
              <div class="col-md-12">
                <div class="formrow">
                  <textarea class="form-control" name="description" placeholder="Add Description About Company"><?php echo @$data[0]->description ?></textarea>
                </div>
              </div>
            </div>
            
            <hr>
            
            <!-- Experience -->
            <!-- <h5>Experience</h5>
            <div class="row">
              <div class="col-md-6">
                <div class="formrow">
                  <input type="text" name="company" class="form-control" placeholder="Company">
                </div>
              </div>
              <div class="col-md-6">
                <div class="formrow">
                  <input type="text" name="webcom" class="form-control" placeholder="Company Website">
                </div>
              </div>
              <div class="col-md-3">
                <div class="formrow">
                  <select class="form-control" name="join-frm">
                    <option>Join From</option>
                    <option>2011</option>
                    <option>2012</option>
                    <option>2013</option>
                    <option>2014</option>
                    <option>2015</option>
                    <option>2016</option>
                  </select>
                </div>
              </div>
              <div class="col-md-3">
                <div class="formrow">
                  <select class="form-control" name="endon">
                    <option>End on</option>
                    <option>2011</option>
                    <option>2012</option>
                    <option>2013</option>
                    <option>2014</option>
                    <option>2015</option>
                    <option>Present</option>
                  </select>
                </div>
              </div>
              <div class="col-md-6">
                <div class="formrow">
                  <input type="text" name="location" class="form-control" placeholder="Location">
                </div>
              </div>
              <div class="col-md-12">
                <div class="formrow">
                  <textarea class="form-control" name="about-company" placeholder="About Company"></textarea>
                </div>
              </div>
            </div>
            <a href="#.">Add Other</a>
            <hr> -->
            
            <!-- Portfolio -->
           <!--  <h5>Portfolio</h5>
            <div class="row">
              <div class="col-md-6">
                <div class="formrow">
                  <input type="text" name="projname" class="form-control" placeholder="Project Name">
                </div>
              </div>
              <div class="col-md-3">
                <div class="formrow">
                  <select class="form-control" name="startfrm">
                    <option>Srart From</option>
                    <option>2011</option>
                    <option>2012</option>
                    <option>2013</option>
                    <option>2014</option>
                    <option>2015</option>
                    <option>2016</option>
                  </select>
                </div>
              </div>
              <div class="col-md-3">
                <div class="formrow">
                  <select class="form-control" name="endon2">
                    <option>End on</option>
                    <option>2011</option>
                    <option>2012</option>
                    <option>2013</option>
                    <option>2014</option>
                    <option>2015</option>
                    <option>Present</option>
                  </select>
                </div>
              </div>
              <div class="col-md-12">
                <div class="formrow">
                  <input type="text" name="projdesc" class="form-control" placeholder="Project Short Description">
                </div>
              </div>
              <div class="col-md-12">
                <div class="formrow">
                  <input type="file" name="image" class="form-control">
                </div>
              </div>
            </div>
            <a href="#.">Add Other</a>
            <hr> -->
            
            <!-- Social -->
          <!--   <h5>Social</h5>
            <div class="row">
              <div class="col-md-6">
                <div class="formrow">
                  <input type="text" name="fb" class="form-control" placeholder="Facebook">
                </div>
              </div>
              <div class="col-md-6">
                <div class="formrow">
                  <input type="text" name="twitter" class="form-control" placeholder="Twitter">
                </div>
              </div>
              <div class="col-md-6">
                <div class="formrow">
                  <input type="text" name="gplus" class="form-control" placeholder="Google Plus">
                </div>
              </div>
              <div class="col-md-6">
                <div class="formrow">
                  <input type="text" name="linkedin" class="form-control" placeholder="Linked In">
                </div>
              </div>
              <div class="col-md-6">
                <div class="formrow">
                  <input type="text" name="pinterest" class="form-control" placeholder="Pinterest">
                </div>
              </div>
              <div class="col-md-6">
                <div class="formrow">
                  <input type="text" class="form-control" placeholder="Behance">
                </div>
              </div>
            </div> -->
            <br>
            <input type="submit" class="btn" value="Save">
        	</form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<style type="text/css">
	label{
		margin-bottom:10px;
		font-weight: 500;
	}
</style><?php /**PATH /var/www/html/new_ondepute/resources/views/company/add_company_info.blade.php ENDPATH**/ ?>